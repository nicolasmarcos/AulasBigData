--Abra o seu navegador na vm > HUE > Query > Query > Mude o ambiente para Hive > Selecione o banco DW e se divirta explorando seus dados!
--Não faça drop das tabelas importadas do sqoop, pois ocasionará perda dos dados

--Para fazer joins, set o parâmetro a seguir
SET hive.auto.convert.join=false;

--Depois de explorar bastante as tabelas, vamos p/ um exemplo:

--Faremos uma fato sumarizada, primeiro, vamos testar a consulta
select f.*, 
    dc.customername, 
    dc.gender,
    dp.productname,
    dsp.salespersonname,
    ds.storename,
    ds.city,
    ds.country
from dw.factproductsales f
left join dw.dimcustomer dc
on f.customerid = dc.customerid
left join dimproduct dp
on f.productid = dp.productkey
left join dimsalesperson dsp 
on f.salespersonid = dsp.salespersonid
left join dimstores ds
on f.storeid = ds.storeid;

--Na sequência, criamos a tabela com base no select
create table fato_sumarizada as
select f.*, 
    dc.customername, 
    dc.gender,
    dp.productname,
    dsp.salespersonname,
    ds.storename,
    ds.city,
    ds.country
from dw.factproductsales f
left join dw.dimcustomer dc
on f.customerid = dc.customerid
left join dimproduct dp
on f.productid = dp.productkey
left join dimsalesperson dsp 
on f.salespersonid = dsp.salespersonid
left join dimstores ds
on f.storeid = ds.storeid;