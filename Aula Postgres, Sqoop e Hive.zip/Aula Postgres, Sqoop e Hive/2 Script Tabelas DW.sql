\c dw

--Adaptado de https://www.codeproject.com/Articles/652108/Create-First-Data-WareHouse#_articleTop 
--e https://wiki.postgresql.org/wiki/Date_and_Time_dimensions
--Gera dimensão cliente e insere dados
Create table DimCustomer
(
CustomerID int primary key,
CustomerAltID varchar(10) not null,
CustomerName varchar(50),
Gender varchar(20)
);

Insert into DimCustomer(CustomerID,CustomerAltID,CustomerName,Gender)values
(1,'IMI-001','Henry Ford','M'),
(2,'IMI-002','Bill Gates','M'),
(3,'IMI-003','Muskan Shaikh','F'),
(4,'IMI-004','Richard Thrubin','M'),
(5,'IMI-005','Emma Wattson','F');

select * from dimcustomer;

-- Gera dimensão produtos e insere dados
Create table DimProduct
(
ProductKey int primary key,
ProductAltKey varchar(10) not null,
ProductName varchar(100),
ProductActualCost money,
ProductSalesCost money

);

Insert into DimProduct(ProductKey, ProductAltKey,ProductName, ProductActualCost, ProductSalesCost)values
(1,'ITM-001','Wheat Floor 1kg',5.50,6.50),
(2,'ITM-002','Rice Grains 1kg',22.50,24),
(3,'ITM-003','SunFlower Oil 1 ltr',42,43.5),
(4,'ITM-004','Nirma Soap',18,20),
(5,'ITM-005','Arial Washing Powder 1kg',135,139);

select * from DimProduct;

--Criaremos a tabela de lojas
Create table DimStores
(
StoreID int primary key,
StoreAltID varchar(10)not null,
StoreName varchar(100),
StoreLocation varchar(100),
City varchar(100),
State varchar(100),
Country varchar(100)
);

Insert into DimStores(StoreID,StoreAltID,StoreName,StoreLocation,City,State,Country )values
(1,'LOC-A1','X-Mart','S.P. RingRoad','Ahmedabad','Guj','India'),
(2,'LOC-A2','X-Mart','Maninagar','Ahmedabad','Guj','India'),
(3,'LOC-A3','X-Mart','Sivranjani','Ahmedabad','Guj','India');

select * from dimstores;


--Criaremos tabela de vendedores
Create table DimSalesPerson
(
SalesPersonID int primary key,
SalesPersonAltID varchar(10)not null,
SalesPersonName varchar(100),
StoreID int,
City varchar(100),
State varchar(100),
Country varchar(100)
);

Insert into DimSalesPerson(SalesPersonID,SalesPersonAltID,SalesPersonName,StoreID,City,State,Country )values
(1,'SP-DMSPR1','Ashish',1,'Ahmedabad','Guj','India'),
(2,'SP-DMSPR2','Ketan',1,'Ahmedabad','Guj','India'),
(3,'SP-DMNGR1','Srinivas',2,'Ahmedabad','Guj','India'),
(4,'SP-DMNGR2','Saad',2,'Ahmedabad','Guj','India'),
(5,'SP-DMSVR1','Jasmin',3,'Ahmedabad','Guj','India'),
(6,'SP-DMSVR2','Jacob',3,'Ahmedabad','Guj','India');

select * from DimSalesPerson;

--Criaremos dimensão tempo

Create Table DimDate as (
SELECT
	datum as Date,
	extract(year from datum) AS Year,
	extract(month from datum) AS Month,
	-- Localized month name
	to_char(datum, 'TMMonth') AS MonthName,
	extract(day from datum) AS Day,
	extract(doy from datum) AS DayOfYear,
	-- Localized weekday
	to_char(datum, 'TMDay') AS WeekdayName,
	-- ISO calendar week
	extract(week from datum) AS CalendarWeek,
	to_char(datum, 'dd. mm. yyyy') AS FormattedDate,
	'Q' || to_char(datum, 'Q') AS Quartal,
	to_char(datum, 'yyyy/"Q"Q') AS YearQuartal,
	to_char(datum, 'yyyy/mm') AS YearMonth,
	-- ISO calendar year and week
	to_char(datum, 'iyyy/IW') AS YearCalendarWeek,
	-- Weekend
	CASE WHEN extract(isodow from datum) in (6, 7) THEN 'Weekend' ELSE 'Weekday' END AS Weekend,
	-- Fixed holidays 
        -- for America
        CASE WHEN to_char(datum, 'MMDD') IN ('0101', '0704', '1225', '1226')
		THEN 'Holiday' ELSE 'No holiday' END
		AS AmericanHoliday,
        -- for Austria
	CASE WHEN to_char(datum, 'MMDD') IN 
		('0101', '0106', '0501', '0815', '1101', '1208', '1225', '1226') 
		THEN 'Holiday' ELSE 'No holiday' END 
		AS AustrianHoliday,
        -- for Canada
        CASE WHEN to_char(datum, 'MMDD') IN ('0101', '0701', '1225', '1226')
		THEN 'Holiday' ELSE 'No holiday' END 
		AS CanadianHoliday,
	-- Some periods of the year, adjust for your organisation and country
	CASE WHEN to_char(datum, 'MMDD') BETWEEN '0701' AND '0831' THEN 'Summer break'
	     WHEN to_char(datum, 'MMDD') BETWEEN '1115' AND '1225' THEN 'Christmas season'
	     WHEN to_char(datum, 'MMDD') > '1225' OR to_char(datum, 'MMDD') <= '0106' THEN 'Winter break'
		ELSE 'Normal' END
		AS Period,
	-- ISO start and end of the week of this date
	datum + (1 - extract(isodow from datum))::integer AS CWStart,
	datum + (7 - extract(isodow from datum))::integer AS CWEnd,
	-- Start and end of the month of this date
	datum + (1 - extract(day from datum))::integer AS MonthStart,
	(datum + (1 - extract(day from datum))::integer + '1 month'::interval)::date - '1 day'::interval AS MonthEnd
FROM (
	-- There are 3 leap years in this range, so calculate 365 * 10 + 3 records
	SELECT '2000-01-01'::DATE + sequence.day AS datum
	FROM generate_series(0,3652) AS sequence(day)
	GROUP BY sequence.day
     ) DQ
);

ALTER TABLE dimdate ADD PRIMARY KEY (date);

select * from DimDate;
select date from dimdate;


--Criação da fato
Create Table FactProductSales
(
TransactionId bigint primary key,
SalesInvoiceNumber int not null,
SalesDateKey Date,
StoreID int not null,
CustomerID int not null,
ProductID int not null,
SalesPersonID int not null,
Quantity float,
SalesTotalCost money,
ProductActualCost money,
Deviation float
);

-- Add relation between fact table foreign keys to Primary keys of Dimensions
AlTER TABLE FactProductSales ADD CONSTRAINT FK_StoreID FOREIGN KEY (StoreID)REFERENCES DimStores(StoreID);
AlTER TABLE FactProductSales ADD CONSTRAINT FK_CustomerID FOREIGN KEY (CustomerID)REFERENCES Dimcustomer(CustomerID);
AlTER TABLE FactProductSales ADD CONSTRAINT FK_ProductKey FOREIGN KEY (ProductID)REFERENCES Dimproduct(ProductKey);
AlTER TABLE FactProductSales ADD CONSTRAINT FK_SalesPersonID FOREIGN KEY (SalesPersonID)REFERENCES Dimsalesperson(SalesPersonID);
AlTER TABLE FactProductSales ADD CONSTRAINT FK_SalesDateKey FOREIGN KEY (SalesDateKey)REFERENCES DimDate(date);

Insert into FactProductSales(TransactionId,SalesInvoiceNumber,SalesDateKey, StoreID,CustomerID,ProductID ,SalesPersonID,Quantity,ProductActualCost,SalesTotalCost,Deviation)values

(1,1,'2009-01-01',1,1,1,1,2,11,13,2),
(2,1,'2009-01-01',1,1,2,1,1,22.50,24,1.5),
(3,1,'2009-01-01',1,1,3,1,1,42,43.5,1.5),

(4,2,'2009-01-01',1,2,3,1,1,42,43.5,1.5),
(5,2,'2009-01-01',1,2,4,1,3,54,60,6),

(6,3,'2009-01-01',1,3,2,2,2,11,13,2),
(7,3,'2009-01-01',1,3,3,2,1,42,43.5,1.5),
(8,3,'2009-01-01',1,3,4,2,3,54,60,6),
(9,3,'2009-01-01',1,3,5,2,1,135,139,4),

(10,4,'2009-01-02',1,1,1,1,2,11,13,2),
(11,4,'2009-01-02',1,1,2,1,1,22.50,24,1.5),

(12,5,'2009-01-02',1,2,3,1,1,42,43.5,1.5),
(13,5,'2009-01-02',1,2,4,1,3,54,60,6),

(14,6,'2009-01-02',1,3,2,2,2,11,13,2),
(15,6,'2009-01-02',1,3,5,2,1,135,139,4),

(16,7,'2009-01-02',2,1,4,3,3,54,60,6),
(17,7,'2009-01-02',2,1,5,3,1,135,139,4),


(18,8,'2009-01-03',1,1,3,1,2,84,87,3),
(19,8,'2009-01-03',1,1,4,1,3,54,60,3),


(20,9,'2009-01-03',1,2,1,1,1,5.5,6.5,1),
(21,9,'2009-01-03',1,2,2,1,1,22.50,24,1.5),

(22,10,'2009-01-03',1,3,1,2,2,11,13,2),
(23,10,'2009-01-03',1,3,4,2,3,54,60,6),

(24,11,'2009-01-03',2,1,2,3,1,5.5,6.5,1),
(25,11,'2009-01-03',2,1,3,3,1,42,43.5,1.5);